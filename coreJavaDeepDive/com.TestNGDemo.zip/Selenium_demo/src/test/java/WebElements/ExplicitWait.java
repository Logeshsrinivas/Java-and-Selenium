package WebElements;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ExplicitWait {
	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
//		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		String url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		driver.get(url);
		WebDriverWait wait =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//input[@name='username']")));
		driver.findElement(By.xpath("//input[@name='username']")).sendKeys("Admin");
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("admin123");
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		WebDriverWait wait1 =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait1.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'])[1]")));
		driver.findElement(By.xpath("(//span[@class='oxd-text oxd-text--span oxd-main-menu-item--name'])[1]")).click();
		WebDriverWait wait2 =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait2.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]")));
		driver.findElement(By.xpath("(//input[@class='oxd-input oxd-input--active'])[2]")).sendKeys("Admin");
		WebDriverWait wait3 =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait3.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'-- Select --')])[1]")));
		driver.findElement(By.xpath("(//div[contains(text(),'-- Select --')])[1]")).sendKeys(Keys.ARROW_DOWN,Keys.ENTER);
//		driver.findElement(By.xpath("//input[@placeholder='Type for hints...']")).sendKeys("Khadar Basha Shaik",Keys.ARROW_DOWN,Keys.ENTER);
		WebDriverWait wait4 =new WebDriverWait(driver,Duration.ofSeconds(10));
		wait4.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[contains(text(),'-- Select --')])")));
		driver.findElement(By.xpath("(//div[contains(text(),'-- Select --')])")).sendKeys(Keys.ARROW_DOWN,Keys.ENTER);		
		driver.findElement(By.xpath("//button[@type='submit']")).click();
		driver.findElement(By.xpath("//span[@class='oxd-userdropdown-tab']")).click();
		driver.findElement(By.xpath("(//a[@role='menuitem'])[4]")).click();
		driver.close();
		



	}
	

}
