package TravelGuru;

public class LoginPage {

}
