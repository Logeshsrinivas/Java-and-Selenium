package TestNG.com.TestNGDemo;

public class ParallelTest {
	

}
